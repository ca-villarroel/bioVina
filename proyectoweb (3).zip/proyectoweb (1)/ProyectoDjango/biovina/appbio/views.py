from django.shortcuts import render
from .models import *
from .forms import *

# Create your views here.

def homed(request):
    listaProductos = Producto.objects.all() #select todos los productos
    datos = {  #variable que lleva los datos de productos
        'producto':listaProductos
    }
    return render(request,'carpetabio/datos.html',datos)


def home(request):
    return render(request, 'carpetabio/blog.html')


def contact(request):
    return render(request, 'carpetabio/contact.html')



def dec(request):
    return render(request, 'carpetabio/dec.html')

    
def fert(request):
    return render(request, 'carpetabio/fert.html')

    
def prod(request):
    return render(request, 'carpetabio/prod.html')


#def form_producto(request):
    form = ProductoForm()
    return render(request,'carpetabio/form_producto.html',{'form':form})

def form_producto(request):    
    datos = {
        'form':ProductoForm()
    }

    if(request.method == 'POST'):
        formulario = ProductoForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            datos['mensaje'] = 'Datos guardados correctamente'
    return render(request,'carpetabio/form_producto.html',datos)


def form_mod_producto(request,id):
    producto = Producto.objects.get(producto=id)  #rescata datos con objects get

    datos ={
        'form':ProductoForm(instance=producto)
    }
    return render(request,'carpetabio/form_mod_producto.html',datos)
