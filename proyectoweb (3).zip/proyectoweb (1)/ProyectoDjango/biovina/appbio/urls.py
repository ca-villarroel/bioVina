from django.urls import path
from .views import *

#HACER FROM DE TODAS LAS PAGINAS.



urlpatterns = [
    path('',home,name='home'),
    path('contact/',contact,name='contact'),
    path('dec',dec,name='dec'),
    path('fert',fert,name='fert'),
    path('prod',prod,name='prod'),
    path('homed',homed,name='datos'), 
    path('agregar_producto',form_producto,name='agregar_producto'), 
    path('modificar_producto/<id>',form_mod_producto,name='modificar_producto'), 
   
]

