from django import forms
from django.forms import ModelForm  #permite crear formulario del modelo
from .models import *  #importamos de models



class ProductoForm(ModelForm):
    class Meta:
        model = Producto
        fields = ['codigo', 'producto', 'marca', 'categoria']


class CategoriaForm(ModelForm):
    class Meta:
        model = Categoria
        fields = ['idCategoria', 'nombreCategoria']      


 