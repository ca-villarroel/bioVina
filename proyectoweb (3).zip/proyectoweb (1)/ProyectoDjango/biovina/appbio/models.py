from django.db import models

# Create your models here.

class Categoria(models.Model):
    idCategoria = models.IntegerField(primary_key=True,verbose_name='Id de categoría')
    nombreCategoria = models.CharField(max_length=50,verbose_name='Nombre de la categoria')

    def __str__(self):
        return self.nombreCategoria

class Producto(models.Model):
    codigo = models.CharField(max_length=10,primary_key=True, verbose_name='Codigo')
    producto = models.CharField(max_length=20, verbose_name='Tipo producto')
    marca = models.CharField(max_length=20,null=True, blank=True, verbose_name='Marca')
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)

    def __str__(self):
        return self.producto

